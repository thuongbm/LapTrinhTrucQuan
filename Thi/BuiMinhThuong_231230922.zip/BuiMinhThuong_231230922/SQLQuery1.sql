﻿INSERT INTO tblThietBi (MaThietBi, TenThietBi, TinhTrang, NgayNhan)
VALUES 
('TB01', N'Máy in Canon LBP2900', N'Đang sử dụng', '2024-10-01'),
('TB02', N'Màn hình Dell 24 inch', N'Bảo hành', '2024-09-15'),
('TB03', N'Bàn phím Logitech K120', N'Hỏng', '2024-10-20');
