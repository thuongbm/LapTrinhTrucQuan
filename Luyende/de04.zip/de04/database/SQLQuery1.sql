﻿INSERT INTO tblNhanVien VALUES
('NV01', N'Nguyễn Văn A', N'0987654321', N'Nam', N'Kế Toán', 8000000, N'anhA.jpg', N'123'),
('NV02', N'Trần Thị B', N'0912345678', N'Nữ', N'Nhân Sự', 9000000, N'anhB.jpg', N'abc123'),
('NV03', N'Lê Văn C', N'0909123456', N'Nam', N'Kỹ Thuật', 10000000, N'anhC.jpg', N'xyz789');